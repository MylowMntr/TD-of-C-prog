// This directive deactivates Warnings for unsecure functions that are deprecated by Microsoft.
// This is not a good practice but is used for pedagogic purposes,
// allowing usage of standard C functions as described in manuals.
// You should use only secured functions named with _s postfix
// e.g. printf_s() rather than printf()
#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <stdlib.h>
#include <locale.h>
#include <conio.h>
#include <math.h>
#include <ctype.h>
/******************************************/
/*   TPC2021 no 3  exo 3-d-e-f-g-h        */
/*                                        */
/******************************************/


#define NBNOTESMAX 5

// fonction swap pour rang
void swap(int *a, int *b)
		{
			int temp = *a;
			*a = *b;
			*b = temp;
		}
// impl�mentation avec un tableau
int main() {
	setlocale(LC_ALL, "fr-FR");

	float val = 0;
	int nbNotes = 0;    // notes valides
	int nbNotesSaisie = 0; // on compte aussi les absents
	float total = 0;		 // somme des notes valides
	int copyNotesetSaisie = 0; // flag
	int nbAbsences = 0;
	float noteMax = 0;
	float noteMin = 20;
	double moyenne = 0;
	//3 - d
	float note[NBNOTESMAX] ;

	// 3-e
	for (int i = 0; i < NBNOTESMAX; i++)
	{
		note[i] = -2;
	}
	// 

	do {
		printf("\nEntrez la note no %d: ", nbNotesSaisie + 1);
		scanf("%f", &val);
		if (val > 20 || val < 0){
			char tmp;
			printf("Eleve absent ? ou voulez-vous copyNoteseter la saisie des notes? A/O/N\n");
			tmp = getch();
			if (tmp == (65)){
				note[nbNotesSaisie] = -1;
				nbAbsences ++;
				nbNotesSaisie ++;
			}
			if (tmp == ('O')){
				printf("Fin des notes.");
				break;
			}
			else{
			}
		}

		else{
			note[nbNotesSaisie] = val;
			nbNotesSaisie++ ;
			nbNotes ++;
			total += val;
			if (val < noteMin){
				noteMin = val;
			}
			if (val > noteMax){
				noteMax = val;
			}
		}
		
	} while ((nbNotesSaisie != NBNOTESMAX) && (copyNotesetSaisie == 0));

	if (nbNotes != 0) {
		moyenne = (float)total / (float)nbNotes;
		printf("\nLa moyenne de ces %d notes est : %.2f\n", nbNotes, moyenne);
		printf("\nIl y a %d absences.", nbAbsences);
		printf("\nLa plus petite note est %.2f, la plus grande est %.2f", noteMin, noteMax);

		// 3-f affichage de l'�cart-type 
		double ecartType = 0;
		double sommeEcart = 0;
		for (int i = 0; i < NBNOTESMAX; i++) {
			sommeEcart += pow(note[i] - moyenne, 2);
		}
		ecartType = sqrt(sommeEcart / nbNotes);
		
		printf("\nL'ecart type vaut : %.2f\n",ecartType);


		// 3 - g : affichage du tableau de notes :
		printf("\n\tNo note\tValeur note");
		for (int i = 0; i < nbNotesSaisie; i++)
		{
			if (note[i] == -1){
				printf("\n\t%d\tAbsent",i+1);
			}
			else{
				printf("\n\t%d\t%.2f",i+1, note[i]);
			}
		}
		printf("\n");

		
		//h - affichage du classement
		int index[NBNOTESMAX];
		float copyNotes[NBNOTESMAX];

		for (int i = 0; i < NBNOTESMAX; i++) {
			copyNotes[i] = note[i];
			index[i] = i+1;
		}
		for (int i = 0; i < NBNOTESMAX-1; i++)     
			for (int j = 0; j < NBNOTESMAX-i-1; j++)
				if (copyNotes[j] < copyNotes[j+1]){
					swap(&copyNotes[j], &copyNotes[j+1]);
					swap(&index[j], &index[j+1]);
				}
		
		printf("\n\tRang\tNo note\tValeur note");
		for (int i = 0; i < NBNOTESMAX; i++) {
			printf("\n\t%d\t%d\t%.2f",i+1, index[i], copyNotes[i]);
		}


	printf("\nBye !\n");

	return(EXIT_SUCCESS);
	}
}
