// This directive deactivates Warnings for unsecure functions that are deprecated by Microsoft.
// This is not a good practice but is used for pedagogic purposes,
// allowing usage of standard C functions as described in manuals.
// You should use only secured functions named with _s postfix
// e.g. printf_s() rather than printf()
#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <stdlib.h>
#include <locale.h>


/******************************************/
/*   TPC2021 no 3  exo 1                  */
/*                                        */
/******************************************/



#define carre(x) x * x

int main() {
	setlocale(LC_ALL, "fr-FR");

	//D�clarer une variable � nb � enti�re et �gale � 5 et afficher la valeur de carre(Nb). 
	int nb = 5;
	
	
	//Afficher en suite le carre(nb + 1), quel est le r�sultat obtenu ?
	printf("%d a pour carre %d\n", nb+1, carre(nb + 1)); 
	

	//D�o� vient le probl�me � votre avis ? 
	// il fait le calcul uniquement le x, il ne prend pas le +1, il faut donc ajouter des parentheses. 

	//Proposer une modification de la macro pour qu�elle fonctionne.
	printf("%d a pour carre %d", nb+1, carre((nb + 1))); 

#ifdef carre
#undef carre
#define carre(x) (x)*(x)
#endif

	printf_s("\nla valeur du carre de %d est egale a %d", nb+1, carre(nb+1));

	printf("\n");

	return(EXIT_SUCCESS);
}